# Demo script (about 5 minutes)

## Before you present
- `streamlit run app/streamlit_app.py`, full screen at 1080p. Wait for the flame (first load takes a few seconds). Check the fps number in the flame panel.
- Have a 60-second screen recording as a backup. Internet is only needed for AI features.
- If you set `OPENAI_API_KEY`, click "Write with AI" once beforehand (results are cached for identical facts).

## 1. The hook (30 s)
"NASA has decades of microgravity fire research, but it is hard to find, compare and interpret, and the Moon and Mars bring conditions nobody has fully tested. This dashboard summarizes, ranks and interprets that evidence, and is honest about what is missing."

## 2. What we can predict (60 s)
Tab *Simulation and analytics*: move oxygen, show the spread rate with its 90% interval, the status badge, and the 3D flame (0g round and blue, 1g illustration). "Real drop-tower experiments, 22 of them, tested by experiment, interval coverage measured."

## 3. The mission question (75 s)
Tab *Mission insights*, scenario "Lunar habitat, exploration atmosphere". Point at the red card: no prediction, with three specific reasons (no 0.16 g data, pressure and oxygen partial pressure below what we tested). Show the **evidence map**: the star sits outside the green band; the dashed purple box shows 1g ground ignition tests do exist at that atmosphere, microgravity tests do not. "The gap is the finding."

## 4. Ranking and risk cards (60 s)
Ranked NASA findings: most relevant first, with score components. Risk cards: only flammability limits has direct measurements; ignition, detection, suppression, materials and ventilation are indirect; every item links to its source and is marked if not yet verified. "A card with no evidence is a data gap, not a sign of safety."

## 5. The AI brief (45 s)
Press *Write with AI*: the model gets only structured facts (show the facts expander); the dashboard checks citations, numbers and structure, and falls back to the rule-based brief if anything fails. Download the brief.

## 6. Compare experiments (30 s)
Tab *Experiments*: compare BASS-II with the ZARM drop tower side by side; show the evidence matrix: planned lunar-gravity platforms are still planned.

## 7. Ask the documents (30 s)
Tab *AI assistant*: an in-scope question with sources, then an out-of-scope one that is declined before any AI call.

## 8. Close (15 s)
"Honest evidence synthesis: what is known, how strong, and what to measure next. Next: more verified findings, partial-gravity data, and extraction at scale."

## Likely questions
- **Why no prediction for the Moon?** Our data is microgravity only and at higher oxygen partial pressure; a number would be a guess. We show evidence and gaps instead.
- **How do you stop the AI making things up?** It only sees structured facts; output must cite known finding IDs, use only numbers from the facts, follow a fixed structure, and avoid 'safe' claims, otherwise it is discarded. See `docs/EVALUATION.md` (9 of 9 corrupted briefs rejected).
- **How reliable is the findings library?** 3 of 16 verified against sources, 13 are labelled unverified; the process to verify and extend it is in `CHALLENGE_REQUIREMENTS.md`.
- **How is ranking decided?** Gravity match 45%, atmosphere match 30%, topic 25% for relevance; final score 70% relevance and 30% strength of evidence (experiment over review over plan). Precision at 3 on a developer-labelled set: 0.87.
- **Can I add data?** Yes: new findings and catalog rows are CSV files with schema validation.
