"""Flame in Freefall: dashboard (steps 4-5: prediction card + charts).
Run from the repo root:  streamlit run app/streamlit_app.py"""
import os, sys
from pathlib import Path
import numpy as np, pandas as pd
import plotly.graph_objects as go
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend")); sys.path.insert(0, str(ROOT))
from ffbackend.predict import Predictor            # noqa: E402
from ffbackend.config import DISCLAIMER             # noqa: E402
sys.path.insert(0, str(Path(__file__).resolve().parent))
from components.flame3d import flame3d              # noqa: E402
from ui import theme                                 # noqa: E402
from insights.findings import load_findings, rank_findings, EVIDENCE_LABEL   # noqa: E402
from insights.scenarios import SCENARIOS, Scenario, evaluate                  # noqa: E402
from insights.brief import build_brief                                         # noqa: E402
from insights.catalog import load_catalog, filter_catalog, compare as compare_entries, evidence_matrix, gravity_class as cat_gravity, TYPES as CAT_TYPES, STATUSES as CAT_STATUSES   # noqa: E402
from insights.si_brief import build_inputs as brief_inputs, generate_brief   # noqa: E402
from insights.risk_cards import build_cards, STATES as RISK_STATES   # noqa: E402
from insights.coverage_map import coverage_figure, coverage_table, atmosphere_status, ppo2_gap, STATUS_TEXT   # noqa: E402

MODEL = Path(os.environ.get("FF_MODEL", ROOT / "backend/artifacts/ff_model.joblib"))
EXPERIMENTS = Path(os.environ.get("FF_EXPERIMENTS", ROOT / "phase0/raw/zarm_experiments_global.csv"))
FUEL, G0 = "PMMA", 0.0
CREDIT = ("Experimental data: ZARM drop-tower flame spread study, Zenodo record 18479713 (GPL-3.0-or-later). "
          "Reports: data provided by NASA Scientific and Technical Information Program "
          "(https://ntrs.nasa.gov/api/openapi/).")
PALETTE = dict(model="#26c6da", band="rgba(38,198,218,0.20)", user="#ce93d8", none="#ffffff", Aluminium="#ffa726", **{"Stainless Steel": "#9aa4b8"})
SYMBOL = {"none": "circle", "Aluminium": "diamond", "Stainless Steel": "triangle-up"}

RAG_DIR = Path(os.environ.get("FF_RAG_DIR", ROOT / "rag"))

st.set_page_config(page_title="Flame in Freefall", page_icon="🔥", layout="wide")

MIN_STREAMLIT = (1, 40)

def keyed_container(key):
    """st.container(key=...) needs Streamlit 1.39+; older versions get a plain container (no card styling) instead of an error."""
    try: return st.container(key=key)
    except TypeError: return st.container()

def show_plot(fig):
    try: st.plotly_chart(fig, width="stretch")
    except TypeError: st.plotly_chart(fig, use_container_width=True)

@st.cache_resource
def load_predictor():
    return Predictor.load(MODEL)

@st.cache_data
def load_experiments():
    d = pd.read_csv(EXPERIMENTS)
    d["o2_pct"] = d["o2_frac"] * 100
    return d

@st.cache_data(show_spinner=False)
def predict_cached(o2_r, f_r):
    return load_predictor().predict_on_line(FUEL, G0, o2_r, f_r)

@st.cache_data(show_spinner=False)
def curve(f_r, lo, hi):
    P = load_predictor(); xs = np.round(np.arange(lo, hi + 1e-9, 0.25), 2)
    rows = [(o, *(lambda r: (r["rate"], r["lo"], r["hi"]))(P.predict_on_line(FUEL, G0, o, f_r))) for o in xs]
    return pd.DataFrame(rows, columns=["o2", "rate", "lo", "hi"]).dropna()

@st.cache_resource
def get_llm():
    """OpenAI client if a key is configured (secrets or environment), else None. Every AI feature falls back without it."""
    key = None
    try: key = st.secrets["OPENAI_API_KEY"]
    except Exception: key = os.environ.get("OPENAI_API_KEY")
    if not key: return None
    from rag.llm import OpenAILLM, LLMError
    from rag.config import AssistantConfig
    try: return OpenAILLM(AssistantConfig(), api_key=key)
    except LLMError: return None

@st.cache_resource
def load_assistant():
    """Returns (assistant, None) or (None, reason). Works without an API key (cache / extractive answers only)."""
    idx, tau = RAG_DIR / "index", RAG_DIR / "tau.json"
    if not (idx / "faiss.index").exists():
        return None, "The assistant is not set up yet: build the document index first (`python scripts/setup_all.py`, then `make rag-index`)."
    if not tau.exists():
        return None, "The refusal threshold is not calibrated yet: run `make rag-calibrate` (see rag/questions.csv)."
    from rag.retrieve import Retriever
    from rag.answer import Assistant, Cache
    from rag.limits import DailyCap
    from rag.llm import OpenAILLM, LLMError
    from rag.config import AssistantConfig
    cfg = AssistantConfig()
    try:
        R = Retriever(idx); R.load_tau(tau)
    except Exception as e:
        return None, f"The assistant index needs rebuilding ({type(e).__name__}): re-run the index and calibration steps."
    llm = get_llm()
    cache = Cache(RAG_DIR / "cache.json", R.embedder, R.meta["corpus_signature"])
    return Assistant(R, llm, cache, cfg, daily=DailyCap(RAG_DIR / "daily_cap.json", cfg.daily_llm_cap),
                     log_path=RAG_DIR / "assistant_log.jsonl"), None

TIER_BADGE = {"LLM": "✔ AI answer grounded in NASA documents", "CACHE": "◷ Cached answer", "EXTRACTIVE": "≡ Passages only (no AI summary)",
              "REFUSED": "✖ Not answered", "RATE_LIMITED": "⏳ Slow down", "INVALID": "⚠ Check your question"}

def render_answer(m):
    st.markdown(m["answer"])
    st.caption(f"{TIER_BADGE.get(m['tier'], m['tier'])}" + (f": {m['label']}" if m.get("label") and m["tier"] in ("CACHE", "REFUSED", "EXTRACTIVE") else ""))
    for src in m.get("sources", []):
        au = ", ".join(a for a in (src.get("authors") or []) if a)
        st.markdown(f"[{src['n']}] [{src['title']}]({src['url']})" + (f", {au}" if au else ""))

def assistant_tab():
    A, why = load_assistant()
    if A is None:
        st.info(why); return
    from rag.limits import TokenBucket
    from rag.config import AssistantConfig
    if "limiter" not in st.session_state: st.session_state.limiter = TokenBucket(AssistantConfig().rate_per_minute)
    st.session_state.setdefault("chat", [])
    st.caption("Answers come only from NASA documents in this repository, with links to the sources. Questions outside them are declined." +
               ("" if A.llm else " AI summaries are off (no API key): you will see cached answers or the closest passages."))
    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            render_answer(m) if m["role"] == "assistant" else st.markdown(m["answer"])
    q = st.chat_input("Ask about microgravity combustion and spacecraft fire safety", max_chars=500)
    if q:
        st.session_state.chat.append(dict(role="user", answer=q))
        with st.chat_message("user"): st.markdown(q)
        with st.chat_message("assistant"), st.spinner("Searching the NASA documents..."):
            res = A.ask(q, st.session_state.limiter); render_answer(res)
        st.session_state.chat.append(dict(role="assistant", **res))

@st.cache_data
def findings_table():
    return load_findings()

@st.cache_data
def catalog_rows():
    return load_catalog()

VERDICT_STYLE = {"COVERED": ("green", "Covered by our experiments"), "NEAR": ("orange", "Just outside our experiments"), "NOT_COVERED": ("red", "Not covered by our experiments")}
SUPPORT_ORDER = {"COVERED": 0, "NEAR": 1, "NOT_COVERED": 2}

def mission_tab(P, exp):
    st.caption("How do NASA's published findings and our microgravity experiments apply to the environments planned for human exploration? "
               "Pick a scenario: the dashboard checks what our data can and cannot say, ranks the most relevant NASA findings, and writes a sourced brief.")
    names = {k: v.name for k, v in SCENARIOS.items()}
    choice = st.selectbox("Mission scenario", list(names) + ["custom"], format_func=lambda k: names.get(k, "Custom environment"), key="scenario_choice")
    if choice == "custom":
        c1, c2, c3 = st.columns(3)
        pk = c1.slider("Total pressure (kPa)", 40.0, 110.0, 56.5, 0.5, key="cus_p")
        ox = c2.slider("Oxygen (%)", 15.0, 40.0, 34.0, 0.5, key="cus_o")
        gg = c3.selectbox("Gravity", [0.0, 0.16, 0.38, 1.0], format_func=lambda g: {0.0: "0 g (microgravity)", 0.16: "0.16 g (Moon)", 0.38: "0.38 g (Mars)", 1.0: "1 g (Earth)"}[g], key="cus_g")
        sc = Scenario("custom", "Custom environment", pk, ox, gg, ("exploration-atmosphere",) if ox > 25 else (), "Environment set by you.")
    else:
        sc = SCENARIOS[choice]
    ev = evaluate(sc, P, exp); ranked = rank_findings(findings_table(), sc.g, sc.o2_pct, sc.pressure_kpa, sc.tags)
    gname = {0.0: "0 g", 0.16: "0.16 g", 0.38: "0.38 g", 1.0: "1 g"}.get(sc.g, f"{sc.g:g} g")
    a, b, c, d = st.columns(4)
    a.markdown(theme.stat_card("Total pressure", f"{sc.pressure_kpa:.1f}", "kPa", "orange", "pressure"), unsafe_allow_html=True)
    b.markdown(theme.stat_card("Oxygen", f"{sc.o2_pct:.1f}", "%", "teal", "flow"), unsafe_allow_html=True)
    c.markdown(theme.stat_card("O2 partial pressure", f"{ev['ppo2']:.1f}", "kPa", "green", "layers"), unsafe_allow_html=True)
    d.markdown(theme.stat_card("Gravity", gname, "", "purple", "status"), unsafe_allow_html=True)

    color, title = VERDICT_STYLE[ev["verdict"]]
    with keyed_container("card_m_cover"):
        st.markdown(theme.card_head(title, "What our 22 microgravity experiments can say about this environment", color), unsafe_allow_html=True)
        if ev["verdict"] == "COVERED":
            p = ev["prediction"]; st.metric("Predicted flame spread rate (thin PMMA)", f"{p['rate']:.2f} mm/s"); st.write(f"90% interval: **{p['lo']:.2f} to {p['hi']:.2f} mm/s**")
        else:
            st.markdown("No prediction is made for this environment." if ev["verdict"] != "NEAR" else "No prediction is made: the environment is just outside the tested range.")
            for r in ev["reasons"]: st.markdown(f"- {r}")
            cm = ev["comparator"]
            if cm: st.caption(f"For orientation only: at {cm['o2_pct']:.1f}% oxygen the nearest tested atmosphere ({cm['pressure_kpa']:.0f} kPa, microgravity) spread at about {cm['rate']:.1f} mm/s ({cm['lo']:.1f} to {cm['hi']:.1f}). Not a prediction for this scenario.")
    with keyed_container("card_m_map"):
        st.markdown(theme.card_head("Evidence map", "Green band: conditions our experiments cover. Stars: planned environments. Dotted lines: constant oxygen partial pressure", "teal"), unsafe_allow_html=True)
        scen_all = {**SCENARIOS, "custom": sc} if choice == "custom" else SCENARIOS
        stt = atmosphere_status(sc.pressure_kpa, sc.o2_pct, exp); gap = ppo2_gap(sc.pressure_kpa, sc.o2_pct, exp)
        st.markdown(f"**Selected atmosphere ({sc.pressure_kpa:.1f} kPa, {sc.o2_pct:.1f}% oxygen): {STATUS_TEXT[stt].lower()}.**" +
                    (f" Its oxygen partial pressure is {gap:.1f} kPa outside the tested range." if gap > 0 else ""))
        show_plot(coverage_figure(exp, scen_all, selected=sc.key, catalog=catalog_rows()))
        with st.expander("Map data as a table (text alternative to the chart)"):
            st.dataframe(coverage_table(exp, scen_all, catalog=catalog_rows()), hide_index=True)
        st.caption("Coverage is judged on pressure and oxygen only; gravity is handled separately: all of our experiments are microgravity. Dashed boxes mark other experiments from the catalog: ground (1g) tests and planned platforms, which are not microgravity tests in this range.")
    with keyed_container("card_m_risk"):
        st.markdown(theme.card_head("Risk cards by topic", "What the evidence says for this environment, topic by topic. A card with no evidence is a data gap, not a sign of safety", "red"), unsafe_allow_html=True)
        st.markdown(theme.risk_cards_html(build_cards(ev, ranked), RISK_STATES), unsafe_allow_html=True)
        st.caption("Only the spread card can show numbers, and only when the environment is covered by our experiments. Everything else is cited findings; items marked 'not yet verified' have not been checked against their sources.")
    with keyed_container("card_m_find"):
        st.markdown(theme.card_head("NASA findings, ranked", "Most relevant first: scored on gravity, atmosphere and topic match, weighted by strength of evidence", "purple"), unsafe_allow_html=True)
        for i, f in enumerate(ranked[:6], 1):
            st.markdown(f"**{i}. {f['finding']}**  \n{EVIDENCE_LABEL[f['evidence']]} · [{f['source_title']}]({f['source_url']}) · score {f['score']:.2f} (relevance {f['relevance']:.2f}, evidence {f['evidence_weight']:.2f})")
        with st.expander("How the ranking works"):
            st.markdown("Score = 0.7 × relevance + 0.3 × evidence strength. Relevance = 0.45 gravity match + 0.30 atmosphere match + 0.25 topic match. "
                        "Evidence strength: partial-gravity experiment 1.0, microgravity experiment 0.9, ground test 0.8, review 0.6, planning or context 0.4. "
                        "Findings are short paraphrases of the cited sources; verify wording against the source.")
    with keyed_container("card_m_brief"):
        st.markdown(theme.card_head("Insight brief", "Every statement traces to our model, our tested ranges, or a cited finding", "teal"), unsafe_allow_html=True)
        rule_brief = build_brief(ev, ranked); inputs = brief_inputs(ev, ranked, build_cards(ev, ranked)); shown = rule_brief
        import hashlib, json as _json
        sig = "ai_brief_" + hashlib.sha256(_json.dumps(inputs, sort_keys=True).encode()).hexdigest()[:16]
        llm = get_llm()
        if llm is None:
            st.caption("AI-written briefs are off (no API key configured). The rule-based brief below is always available and fully sourced.")
        else:
            from rag.limits import TokenBucket, DailyCap
            from rag.config import AssistantConfig
            if st.button("Write with AI (verified)", key="brief_ai", help="A language model writes the brief from the facts above; the dashboard checks citations, numbers and structure before showing it."):
                lim = st.session_state.setdefault("brief_limiter", TokenBucket(5))
                if lim.allow():
                    st.session_state[sig] = generate_brief(llm, inputs, rule_brief, DailyCap(RAG_DIR / "daily_cap.json", AssistantConfig().daily_llm_cap))
                else:
                    st.session_state[sig] = dict(tier="RULE_BASED", text=rule_brief, reasons=["Too many AI requests in a short time; please wait a moment."], cached=False)
            res = st.session_state.get(sig)
            if res:
                shown = res["text"]
                if res["tier"] == "SI": st.success("✔ AI-written brief. Citations, numbers and structure were checked against the facts.")
                else: st.warning("Showing the rule-based brief. " + " ".join(res["reasons"]))
        st.markdown(shown)
        with st.expander("What the AI is given (the facts)"):
            st.json(inputs)
        st.download_button("Download brief (Markdown)", shown, file_name=f"insight_brief_{sc.key}.md", mime="text/markdown")
    with keyed_container("card_m_all"):
        st.markdown(theme.card_head("All scenarios at a glance", "Ranked by how directly our experiments cover them", "orange"), unsafe_allow_html=True)
        rows = []
        for k, s in SCENARIOS.items():
            e = evaluate(s, P, exp); top = rank_findings(findings_table(), s.g, s.o2_pct, s.pressure_kpa, s.tags)[0]
            rows.append(dict(Scenario=s.name, Gravity=f"{s.g:g} g", Pressure_kPa=s.pressure_kpa, Oxygen_pct=s.o2_pct, O2_partial_kPa=round(e["ppo2"], 1),
                             Support=VERDICT_STYLE[e["verdict"]][1], Predicted_mm_s=(round(e["prediction"]["rate"], 2) if e["prediction"] else None),
                             Most_relevant_finding=top["id"] + ": " + top["finding"][:90] + "...", _o=SUPPORT_ORDER[e["verdict"]]))
        df = pd.DataFrame(rows).sort_values("_o").drop(columns="_o")
        st.dataframe(df, hide_index=True)

GRAV_LABEL = {"micro": "Microgravity", "lunar": "Lunar gravity", "mars": "Mars gravity", "earth": "Earth gravity (1g)", "unknown": "Not stated"}

def experiments_tab():
    rows = catalog_rows()
    st.caption("Find and compare the experiments and facilities behind NASA's microgravity fire research. Entries marked 'No' have not been checked against their sources yet.")
    with keyed_container("card_x_filter"):
        st.markdown(theme.card_head("Find experiments", "Filter by platform, gravity, status or keyword", "purple"), unsafe_allow_html=True)
        c1, c2, c3 = st.columns(3)
        types = c1.multiselect("Platform", CAT_TYPES, key="x_types")
        grav = c2.multiselect("Gravity", list(GRAV_LABEL), format_func=lambda g: GRAV_LABEL[g], key="x_grav")
        stat = c3.multiselect("Status", CAT_STATUSES, key="x_stat")
        c4, c5 = st.columns([3, 1])
        text = c4.text_input("Keyword (name, fuel, measurement, result)", key="x_text")
        vonly = c5.checkbox("Verified only", key="x_ver")
        hits = filter_catalog(rows, types=types or None, gravity=grav or None, status=stat or None, text=text, verified_only=vonly)
        st.markdown(f"**{len(hits)} of {len(rows)} entries**")
        if hits:
            df = pd.DataFrame([dict(ID=r["id"], Name=r["name"], Platform=r["type"], Gravity=GRAV_LABEL[cat_gravity(r)], Status=r["status"],
                                    Verified="Yes" if r["verified"] == "yes" else "No", Key_result=r["key_result"], Source=r["source_url"]) for r in hits])
            st.dataframe(df, hide_index=True, column_config={"Source": st.column_config.LinkColumn("Source", display_text="open")})
        else:
            st.info("No entries match these filters.")
    with keyed_container("card_x_compare"):
        st.markdown(theme.card_head("Compare experiments", "Choose two to four entries for a side-by-side view", "teal"), unsafe_allow_html=True)
        names = {r["id"]: f"{r['id']}: {r['name']}" for r in rows}
        pick = st.multiselect("Entries to compare", list(names), default=["E02", "E07"], format_func=lambda i: names[i], max_selections=4, key="x_pick")
        if len(pick) >= 2:
            st.dataframe(compare_entries(rows, pick))
        else:
            st.info("Select at least two entries.")
    with keyed_container("card_x_matrix"):
        st.markdown(theme.card_head("Where is the evidence?", "Entries in this catalog by gravity and status", "orange"), unsafe_allow_html=True)
        m = evidence_matrix(rows).rename(index=GRAV_LABEL)
        st.dataframe(m)
        n_lunar_flown = int(m.loc["Lunar gravity"].get("flown", 0)) if "Lunar gravity" in m.index else 0
        st.markdown("In this catalog, **no experiment has flown at lunar gravity with a published spread-rate dataset**, and the planned lunar-gravity platforms are still planned." if n_lunar_flown == 0 else "")
        st.caption("Counts reflect the entries in this catalog only, not everything NASA has done.")

def main():
    try:
        ver = tuple(int(x) for x in st.__version__.split(".")[:2])
        if ver < MIN_STREAMLIT:
            st.warning(f"Streamlit {st.__version__} is old; some styling and features need {'.'.join(map(str, MIN_STREAMLIT))} or newer. Run: pip install -U streamlit")
    except ValueError:
        pass
    st.markdown(theme.css(), unsafe_allow_html=True)
    st.title("Flame in Freefall")
    st.caption("Flame spread over thin PMMA in microgravity (ZARM drop tower). Research and educational tool.")
    try:
        P = load_predictor(); exp = load_experiments()
    except Exception as e:                                       # REQ-A5: clear setup error, not a traceback
        st.error(f"Setup problem: could not load the model or data ({type(e).__name__}). Run `make train` first.")
        st.stop()

    lo, hi = P.safe_o2_range(FUEL, G0, 1.0)
    with st.sidebar:
        st.header("Conditions")
        st.markdown(f"**Fuel:** {FUEL} thin film, 75 µm")
        gravity = st.radio("Gravity", ["0g (microgravity)", "1g (Earth)"], index=0)
        reduce_motion = st.checkbox("Reduce motion", value=False)
        o2 = st.slider("Oxygen (%)", float(round(lo + 0.05, 1)), float(round(hi - 0.05, 1)), 28.0, 0.5,
                       help="Pressure and flow in the experiments were tied to oxygen, so only oxygen is free.")
        f = st.slider("Fuel coverage f*", 0.72, 1.00, 1.00, 0.01,
                      help="Fraction of the strip that is fuel; 1.0 is a continuous strip, lower values have metal barriers.")
    cond = P.conditions_for(FUEL, G0, o2)
    is_1g = gravity.startswith("1g")
    res = None if is_1g else predict_cached(round(o2 * 2) / 2, round(f, 2))
    status = "n/a" if res is None else res["status"]

    tab1, tab_m, tab_x, tab2 = st.tabs(["Simulation and analytics", "Mission insights", "Experiments", "AI assistant"])
    with tab1:
        banner = st.empty()      # fixed slot: inserting/removing a banner would shift the layout and remount the 3D iframe
        if is_1g:
            banner.warning("No 1g measurements in this dataset. The 1g view is an illustration only and shows no prediction.")
        else:
            banner.empty()
        s1, s2, s3, s4 = st.columns(4)
        s1.markdown(theme.stat_card("Pressure", f"{cond[0]:.0f}", "kPa", "orange", "pressure"), unsafe_allow_html=True)
        s2.markdown(theme.stat_card("Opposed flow", f"{cond[1]:.0f}", "mm/s", "teal", "flow"), unsafe_allow_html=True)
        s3.markdown(theme.stat_card("Fuel coverage", f"{f:.2f}", "", "green", "layers"), unsafe_allow_html=True)
        label, color, icon = {"IN": ("In range", "green", "status"), "SPARSE": ("Sparse data", "orange", "alert"), "OUT": ("Out of range", "red", "alert"),
                              "n/a": ("No 1g data", "purple", "alert")}.get(status, ("Unknown", "red", "alert"))
        s4.markdown(theme.stat_card("Data coverage", label, "", color, icon), unsafe_allow_html=True)

        c1, c2 = st.columns([1, 2])
        with c1:
            with keyed_container("card_pred"):
                st.markdown(theme.card_head("Predicted spread rate", "Model estimate with a 90% interval", "green"), unsafe_allow_html=True)
                if res is None:
                    st.info("Prediction available for 0g only.")
                elif res["status"] == "OUT":
                    st.error(f"✖ OUT: Experimental Bounds Exceeded. {res['message']}")
                else:
                    st.metric("Flame spread rate", f"{res['rate']:.2f} mm/s",
                              help="Model estimate with a 90% interval from cross-validated residuals.")
                    st.write(f"90% interval: **{res['lo']:.2f} to {res['hi']:.2f} mm/s**")
                    if res["status"] == "IN":
                        st.success("✔ IN: within the tested envelope.")
                    else:
                        st.warning(f"⚠ SPARSE: {res['message']} Interval widened.")
                st.caption("Estimate from 22 experiments, one apparatus. " + DISCLAIMER)
        with c2:
            with keyed_container("card_flame"):
                st.markdown(theme.card_head("3D flame", "Speed follows the predicted spread rate", "purple"), unsafe_allow_html=True)
                ok = (not is_1g) and res is not None and res["status"] != "OUT"
                flame3d(rate=res["rate"] if ok else (4.0 if is_1g else None), gravity=1 if is_1g else 0, o2=o2, flow=cond[1],
                        status="IN" if is_1g else (res["status"] if res else "OUT"), reduce_motion=reduce_motion, illustration=is_1g)

        with keyed_container("card_chart"):
            st.markdown(theme.card_head("Prediction versus experiments", "Real experiments, the model curve and its 90% interval", "orange"), unsafe_allow_html=True)
            fig = go.Figure()
            cv = curve(round(f, 2), float(round(lo, 2)), float(round(hi, 2)))
            fig.add_trace(go.Scatter(x=cv.o2, y=cv.hi, mode="lines", line=dict(width=0), showlegend=False, hoverinfo="skip"))
            fig.add_trace(go.Scatter(x=cv.o2, y=cv.lo, mode="lines", line=dict(width=0), fill="tonexty",
                                     fillcolor=PALETTE["band"], name="90% interval"))
            fig.add_trace(go.Scatter(x=cv.o2, y=cv.rate, mode="lines", name=f"Model (f*={f:.2f})",
                                     line=dict(color=PALETTE["model"], width=3)))
            for mat, d in exp.groupby("gap_material"):
                lab = "Continuous PMMA (f*=1)" if mat == "none" else f"{mat} barriers"
                fig.add_trace(go.Scatter(x=d.o2_pct, y=d.v_mm_s, mode="markers", name=lab,
                                         error_y=dict(type="data", array=d.v_sd_mm_s, visible=True),
                                         marker=dict(symbol=SYMBOL[mat], size=10, color=PALETTE[mat], line=dict(width=1, color=theme.CARD)),
                                         customdata=np.c_[d.exp, d.f_star], hovertemplate="%{customdata[0]}<br>O2 %{x:.1f}%<br>rate %{y:.2f} mm/s<br>f* %{customdata[1]:.2f}<extra></extra>"))
            if res is not None and res["status"] != "OUT":
                fig.add_trace(go.Scatter(x=[o2], y=[res["rate"]], mode="markers", name="Your selection",
                                         marker=dict(symbol="star", size=18, color=PALETTE["user"], line=dict(width=1.5, color="#FFFFFF"))))
            fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                              font=dict(family="Roboto, Helvetica Neue, Arial, sans-serif", color="#dfe4ee", size=13),
                              xaxis=dict(title="Oxygen (%)", gridcolor="rgba(255,255,255,0.08)", zerolinecolor="rgba(255,255,255,0.12)"),
                              yaxis=dict(title="Flame spread rate (mm/s)", gridcolor="rgba(255,255,255,0.08)", zerolinecolor="rgba(255,255,255,0.12)"),
                              height=440, legend=dict(orientation="h", y=-0.25), margin=dict(t=10))
            show_plot(fig)
            with st.expander("Chart data as a table (text alternative to the chart)"):
                st.dataframe(exp[["exp", "o2_pct", "f_star", "gap_material", "v_mm_s", "v_sd_mm_s"]].rename(columns={"exp": "Experiment", "o2_pct": "Oxygen (%)", "f_star": "Fuel coverage", "gap_material": "Barrier", "v_mm_s": "Spread rate (mm/s)", "v_sd_mm_s": "Std (mm/s)"}), hide_index=True)
                if res is not None and res["status"] != "OUT":
                    st.write(f"Your selection: oxygen {o2:.1f} %, fuel coverage {f:.2f}, predicted {res['rate']:.2f} mm/s (90% interval {res['lo']:.2f} to {res['hi']:.2f}).")
            st.caption("Markers use different shapes per barrier material (not only color). Curve shows the model at the selected fuel coverage; real experiments have different coverage values.")
    with tab_m:
        mission_tab(P, exp)
    with tab_x:
        experiments_tab()
    with tab2:
        with keyed_container("card_chat"):
            st.markdown(theme.card_head("Ask the NASA documents", "Answers only from the harvested reports, with sources", "teal"), unsafe_allow_html=True)
            assistant_tab()
    st.divider()
    st.caption(DISCLAIMER); st.caption(CREDIT)

main()
