# Flame in Freefall: Challenge Requirements (v3)

Companion to `ENGINEERING_REQUIREMENTS.md`. This file defines what still has to be built to answer the challenge, how it plugs into the existing code, and the order to build it in.

> **The challenge:** create an interactive, super-intelligence (SI) powered dashboard that **summarizes, ranks, and interprets** NASA's microgravity fire findings to deliver **fire-safety insights for human space exploration** (Moon and Mars). The volume of results makes them hard to **find, compare, and understand**.

---

## 0. Progress

| Step | Status |
|---|---|
| C1 Evidence coverage map | Done (with overlay of ground tests and planned platforms) |
| C2 Experiment catalog and comparison tab | Done (11 entries; 2 verified) |
| C4 Risk cards | Done |
| C3 SI-written brief with verifier and fallback | Done (tested with a mock LLM; needs your API key for real runs) |
| C10 Evaluation and documents | Done: `docs/EVALUATION.md`, README, DEMO_SCRIPT, DATA_CARD updated. Deployment (v2 step 12) still to do |
| C5 Ranking v2, C6 extraction pipeline, C7 report export, C8 natural-language scenarios, C9 summaries | Not started |

## 1. Where we stand against the challenge

| Challenge need | Status | What exists | What is missing |
|---|---|---|---|
| **Find** findings and experiments | Partial | NTRS harvester, FAISS search, cited Q&A assistant | A browsable catalog of experiments and facilities; findings library is only 16 hand-curated entries |
| **Compare** experiments | Missing | Plot of our 22 experiments | Side-by-side comparison of facilities, conditions, and results; a map of what is tested versus what missions need |
| **Summarize** | Missing | Per-answer retrieval only | Per-document summaries; topic-level synthesis from verified findings |
| **Rank** | Partial | Findings ranked by gravity, atmosphere, topic match and evidence strength (`insights/findings.py`); scenarios ranked by data coverage | Semantic relevance, recency, adjustable weights, evaluation of ranking quality |
| **Interpret** | Partial | Mission scenarios, honest coverage check, rule-based brief (`insights/`) | SI-written briefs that are verified; natural-language scenarios; risk cards (spread, limits, detection, suppression, materials, ventilation) |
| **Fire-safety insights for exploration** | Partial | Exploration atmospheres (56.5 kPa / 34% O2, 70.3 kPa / 26.5% O2), lunar and Mars gravity scenarios | Insights across more mission contexts; exportable report |
| **SI-powered** | Partial | LLM assistant with citation checks | LLM used for extraction, summaries, scenario parsing, and briefs, each verified, each with a no-API-key fallback |

### Key facts that shape the design
- NASA's planned exploration atmosphere is 56.5 kPa (8.2 psia) with 34% oxygen; an alternative is 70.3 kPa (10.2 psia) with 26.5%. Lunar gravity is 0.16 g.
- Our 22 experiments cover oxygen 21.6 to 36.0%, pressure 61.6 to 103.1 kPa, oxygen partial pressure 21.5 to 25.3 kPa, all in microgravity. The exploration atmosphere has about 19.2 kPa partial pressure, so **it is outside our data**. The dashboard must keep saying so, and replace prediction with ranked evidence and gaps.
- Therefore the main value is **evidence synthesis and gap analysis**, not extrapolation.

---

## 2. Principles (apply to every new feature)

1. **Traceable:** every statement links to a finding ID, a model output, or a tested range. No unsourced numbers.
2. **Honest gaps:** if the evidence does not cover a scenario, say so and say what data is missing.
3. **Verified labels:** each finding carries `verified` (a human checked it against the source) or `unverified`. The UI shows the badge. LLM output never enters the library without human approval.
4. **Copyright and terms:** store short paraphrases (target 40 words), at most one quote of 15 words per source, always link the NTRS citation URL, check each record's copyright flag, and run the weekly redistributions sync.
5. **Works without an API key:** every LLM feature has a deterministic fallback, so the dashboard never breaks and tests run offline.
6. **LLM output is verified in code:** citation IDs must exist, numbers must match the inputs, otherwise fall back.
7. **Accessibility and performance targets from v2 still apply** (axe: 0 violations, p95 interactions under 100 ms for non-LLM paths).

---

## 3. Data schemas

### 3.1 Findings library (extend `insights/findings_seed.csv`)
Existing columns: `id, finding, topics, gravity, o2_min, o2_max, p_min_kpa, p_max_kpa, evidence, source_title, source_url, year, note`.
Add: `verified` (yes/no), `verified_on` (date), `source_page` (page or section), `fuel_or_material` (optional), `direction` (increase / decrease / none: effect on flammability or spread, optional), `category` (one of: spread, limit, ignition, detection, suppression, materials, ventilation, atmosphere, methods).
Controlled topic vocabulary in `insights/vocab.py`; unknown topics are rejected by the validator.

### 3.2 Experiment and facility catalog (new `insights/experiments_catalog.csv`)
`id, name, type (ISS, drop tower, rocket, parabolic flight, ground, planned), gravity_g (value or range), duration_s, atmosphere_o2_min, atmosphere_o2_max, pressure_kpa_min, pressure_kpa_max, fuels, geometry, flow_cm_s_min, flow_cm_s_max, measurements, status (flown, complete, planned), data_access (PSI, Zenodo, report only), key_result (one sentence), source_url, verified`.
Initial entries (each needs a source and verification): BASS, BASS-II, SoFIE, Saffire I to VI, LUCI, ACME, ZARM drop-tower thin PMMA (this dashboard's data), NASA-STD-6001 Test 1, a planned lunar-g capsule experiment.

### 3.3 Candidate findings (new `insights/findings_candidates.csv`)
Same columns as 3.1 plus `proposed_by` (llm model name or human), `chunk_ref`, `status` (pending, approved, rejected). Only approved rows are merged into the library.

---

## 4. Requirements by feature

### REQ-E1 Evidence coverage map (find, compare, interpret)
- Interactive Plotly chart: x = total pressure (kPa), y = oxygen (%). Show our 22 experiments (markers by barrier type), iso-lines of oxygen partial pressure (for example 19, 21, 25 kPa), catalog experiments as rectangles or points where ranges are known, and planned environments as stars (ISS cabin, 10.2 psia / 26.5%, 8.2 psia / 34%).
- Shaded region = "covered by our data". Planned environments outside it are labelled "not covered" with the distance in partial pressure.
- Text table equivalent (accessibility). Marker shapes differ, not only colors.
- Acceptance: the 8.2 psia / 34% star lies outside the covered region; the ISS cabin star is on the edge; a test checks both.

### REQ-E2 Experiment and facility catalog with comparison (find, compare)
- New tab "Experiments": filter by type, gravity, atmosphere, fuel, flow, status; select 2 to 4 entries for a side-by-side table with aligned fields and blanks shown as "not reported".
- Each entry shows verification badge and source link; data-access hint (PSI, Zenodo, report only).
- Acceptance: schema validator passes; every row has a `source_url`; comparing 3 entries returns a table with identical rows; filter results are correct on a fixture.

### REQ-E3 Findings pipeline at scale (find, summarize; SI-powered)
- `insights/extract.py`: for each indexed chunk, call the LLM with a JSON schema to propose findings (paraphrase of 40 words or fewer, category, topics from the vocabulary, gravity, oxygen and pressure if stated, evidence type, page). Validate against the schema, drop any proposal containing a quote longer than 15 words, deduplicate against the library using embedding similarity, write to `findings_candidates.csv`.
- `insights/review.py` (Streamlit page or CLI): show candidate, source link, and edit fields; approve or reject; approved rows are appended to the library with `verified=yes`.
- Dashboard shows all findings but marks `unverified` ones and ranks verified ones higher (small penalty).
- Acceptance (mock LLM): valid proposals are written, invalid or over-quoted ones are rejected with reasons, duplicates are skipped, approval merges one row, nothing unapproved appears in the library.

### REQ-E4 Summaries (summarize)
- **Per-document summary** (120 words or fewer) generated at build time from the document's chunks, stored in `rag/summaries.json` with source ID; extractive fallback (first informative sentences) when no key. Shown in a "Document explorer" list with filters.
- **Topic synthesis**: "What do we know about [topic]?" built only from verified findings of that topic: counts by evidence type, agreement or conflict (if `direction` values disagree, show the conflict), top 3 findings, gaps.
- Acceptance: summaries cite the source; the synthesis contains no statement without a finding ID; conflicting directions are flagged on a fixture.

### REQ-E5 Ranking v2 (rank)
- Keep the current score and explain it. Add: semantic relevance (embedding similarity between scenario or question text and finding), recency bonus (small), verified bonus, and user-adjustable weights (sliders for gravity, atmosphere, topic, evidence).
- Ranking is deterministic for fixed inputs.
- Evaluation: a hand-labelled set of at least 8 scenarios or questions with expected relevant finding IDs; report precision at 3 and show it in `docs/EVALUATION.md`.
- Acceptance: precision at 3 is at least 0.6 on the labelled set (target to tune); ranking changes in the expected direction when a weight changes.

### REQ-E6 SI-written insight brief (interpret; SI-powered)
- Inputs to the LLM are structured: scenario facts, model verdict and numbers, ranked findings (IDs and paraphrases), data gaps. Output: a brief of at most 250 words, every claim tagged with finding IDs like [F07], plus up to two follow-up questions.
- Verifier: every ID exists and was in the input; every number in the text equals a number in the input; no sentence of factual content without an ID; length limit; the disclaimer is present. Failure triggers the rule-based brief (existing `insights/brief.py`) and a note.
- Cost and safety: 400 token cap, 8 s timeout, one retry, per-session limit, daily cap (reuse `rag/answer.py` limiter classes).
- Acceptance (mock LLM): a good output passes; hallucinated number, unknown ID, missing citation, and over-length outputs each fall back; no key falls back.

### REQ-E7 Natural-language scenarios (interpret; SI-powered)
- Box in the Mission tab: "Describe a scenario, for example: lunar habitat at 8 psi and 30% oxygen". The LLM returns JSON (pressure, unit, oxygen percent, gravity name or value, context). Code validates ranges, converts psi, atm, and bar to kPa, maps Moon, Mars, ISS, and free fall to gravity values, and shows the parsed scenario for confirmation before use.
- Deterministic regex parser as fallback for common phrasings; if parsing is ambiguous, ask a clarifying question instead of guessing.
- Acceptance: at least 10 phrasings parse correctly (units, ranges, names); out-of-range or ambiguous input is rejected or clarified; no numbers invented.

### REQ-E8 Risk cards per scenario (interpret; fire-safety insights)
- For the chosen scenario show cards for: flame spread tendency, flammability limits, ignition, detection, suppression, materials and hardware, ventilation. Each card has a state: **Evidence-supported** (verified findings with matching gravity or atmosphere), **Limited** (indirect evidence), **No data**, with the findings and gaps listed. No new numbers.
- Mapping from findings categories and topics to cards in `insights/risk_cards.py`.
- Acceptance: for the lunar exploration scenario the limits and materials cards are Evidence-supported or Limited, the spread card says no prediction, and a card with no matching findings says No data.

### REQ-E9 Report export (interpret)
- Download a Markdown (and HTML) report: scenario, coverage verdict, ranked findings with links, risk cards, brief, data-version signature (corpus and findings hashes), timestamp, disclaimer.
- Acceptance: file contains all sections and sources; regenerating with the same inputs gives identical content except the timestamp.

### REQ-E10 Evaluation and hardening
- `docs/EVALUATION.md`: ranking precision at 3, citation validity (target 100%), numeric fidelity of briefs (target 100%), refusal rate on out-of-scope questions, extraction approval rate, latency.
- Re-run accessibility, resource, and end-to-end tests with the new tabs; update README, DEMO_SCRIPT, DATA_CARD; deployment (step 12) afterwards.

---

## 5. How it plugs into the existing code

| Existing piece | Change |
|---|---|
| `insights/findings.py` | extend CSV columns; add verified bonus, recency, semantic score, adjustable weights |
| `insights/scenarios.py` | add scenario library entries and the parser hook; keep `evaluate()` honesty rules |
| `insights/brief.py` | keep as the fallback brief; add `si_brief.py` for the LLM version and verifier |
| `rag/answer.py` | reuse `TokenBucket`, `DailyCap`, `LLMError`, `OpenAILLM`, `MockLLM`; add a JSON-mode helper |
| `rag/build_index.py`, `rag/retrieve.py` | feed chunks to `extract.py` and `summarize.py`; use the embedder for semantic ranking |
| `app/streamlit_app.py` | Mission tab gains: coverage map, risk cards, NL box, adjustable weights, export; new tabs "Experiments" and (optional) "Documents" |
| `app/ui/theme.py` | no change except small helpers for badges |
| `scripts/setup_all.py`, `Makefile` | add insights tests, `make insights-extract`, `make insights-summarize` |

New modules: `insights/{vocab,catalog,coverage_map,extract,review,summarize,rank_eval,si_brief,query_parser,risk_cards,report}.py`, data files `insights/experiments_catalog.csv`, `insights/findings_candidates.csv`, tests `insights/tests/test_*.py`.

---

## 6. Implementation steps

Each step ends with passing tests and a commit. Effort assumes focused work. Tiers: **Must** for a convincing hackathon submission, **Should** for strength, **Could** if time remains.

| # | Step | Tier | Needs LLM key | Needs your input | Est. |
|---|---|---|---|---|---|
| C1 | Evidence coverage map (REQ-E1) | Must | no | none | 3 h |
| C2 | Experiment and facility catalog plus compare tab (REQ-E2) | Must | no | verify catalog rows against sources | 4 h |
| C3 | SI-written brief with verifier and fallback (REQ-E6) | Must | for real runs; tests use mock | API key | 4 h |
| C4 | Risk cards (REQ-E8) | Must | no | review wording | 3 h |
| C5 | Ranking v2 plus labelled evaluation set (REQ-E5) | Should | no | review the labelled set | 3 h |
| C6 | Findings extraction pipeline plus review tool (REQ-E3) | Should | for real runs | harvested corpus, approve candidates | 6 h |
| C7 | Report export (REQ-E9) | Should | no | none | 2 h |
| C8 | Natural-language scenarios (REQ-E7) | Could | optional (regex fallback) | none | 3 h |
| C9 | Summaries and topic synthesis (REQ-E4) | Could | for real runs | harvested corpus | 3 h |
| C10 | Evaluation, docs, a11y, deploy (REQ-E10 plus v2 step 12) | Must | no | accounts for deployment | 4 h |

Total about 35 h; the Must tier is about 18 h. Suggested order: C1, C2, C4, C3, C5, C7, C6, C8, C9, C10.

---

## 7. Acceptance for the whole challenge

- [ ] A user can pick or describe a mission scenario and see: what our data covers, the evidence map, ranked NASA findings, risk cards, and a sourced brief.
- [ ] Experiments and facilities can be browsed, filtered, and compared.
- [ ] Every finding shows a source link and a verified badge; unverified items are never presented as confirmed.
- [ ] No statement or number appears without a traceable source; LLM output that fails verification is replaced by the rule-based version.
- [ ] Everything works without an API key (rule-based), and better with one.
- [ ] Out-of-scope scenarios (for example lunar gravity at the exploration atmosphere) are labelled not covered, with the specific data gaps.
- [ ] Tests, accessibility scan, and resource tests pass; README, DEMO_SCRIPT, DATA_CARD, EVALUATION updated.

## 8. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Findings library is small and hand-curated | C6 pipeline with human review; keep claims limited to verified entries |
| LLM extraction or briefs hallucinate | Schema validation, quote limits, ID and number verification, human approval, rule-based fallback |
| Needs the NASA corpus, which only your machine can fetch | Build and test with mock LLM and fixtures; you run `setup_all.py` and the extraction, then review candidates |
| Catalog facts could be wrong | `verified` flag; every row has a source; verify against the source before the demo |
| Copyright or terms | Short paraphrases, link citation URLs, respect copyright flags, weekly sync |
| Scope too large | Tiers: ship Must first; each step is independently useful |
| Judges expect predictions for Moon and Mars | Be explicit: our data is microgravity only; the dashboard's value is honest evidence synthesis and gap identification |
