# Your checklist: everything only you can do

This is the complete walkthrough for the parts of the project I cannot do from my side: checking the evidence against its sources, running the real AI, checking the flame on your graphics card, and putting the dashboard online. Total time: about 3 to 5 hours, spread as you like. Do the parts in order.

Commands are shown for **Windows (PowerShell or Command Prompt)**. On Mac or Linux use `python3` instead of `python`. Open the terminal **inside the unzipped project folder** (the one that contains `app`, `backend`, `insights`, `scripts`). Windows has no `make`, so every command below is the plain Python version.

---

## Part A. Install, test, and fetch the NASA documents (20 to 30 minutes, needs internet)

1. Unzip `flame-in-freefall.zip` (replace your old folder if you have one; keep `rag/corpus`, `rag/index` and `rag/tau.json` if you already built them).
2. Check Python: `python --version` (3.11 or 3.12 recommended).
3. Run: `python scripts/setup_all.py --per-query 5`
   - It installs the packages, audits the data, trains the model, runs every test, harvests NASA reports, and builds the search index.
   - You should see many lines ending `PASS`. The NASA steps need internet; if they say `SKIP (not reachable)`, check VPN or proxy and rerun.
4. When it finishes, open `SETUP_REPORT.md`. If anything says `FAIL`, send me that file.
5. Open `rag/index/excluded.csv`: these documents were left out as off-topic or not downloadable. If an important paper is in there, tell me its title.
6. Open `rag/questions.csv` in Excel. Each in-scope question (label `in`) must be answerable from the documents you downloaded. **Delete rows whose answer is not in your documents** (otherwise the refusal threshold will be too low).
7. Run: `python scripts/setup_all.py --calibrate --skip-install`
   - Check `rag/tau.json`: `auc` should be at least 0.9 and `warnings` empty. If not, send it to me.

---

## Part B. Verify the evidence (1.5 to 3 hours)

**Why:** the dashboard shows 13 findings and 9 catalog entries marked "not yet verified". They are paraphrases of source excerpts. Judges can click the links, so each one should say what its source says.

### How to use the tool
- Findings: `python scripts/verify_entries.py findings`
- Catalog: `python scripts/verify_entries.py catalog`

For each entry it shows the claim, the link, and what to search for. **Open the link, press Ctrl+F in the document, search for the numbers and key words shown, and read the passage.** Then answer:

| Key | When to use it |
|---|---|
| `y` | The source says this (same meaning, same numbers). It asks for the page or section and records today's date |
| `e` | The idea is right but the wording or a number is wrong: type corrected wording (one line, at most 40 words, your own words, no long quotes), then confirm with `y` |
| `n` | You could not find it or cannot confirm: it stays "unverified" and a note is added |
| `d` | The source does not say this at all: delete it (you must type DELETE) |
| `s` | Skip for now |
| `q` | Save and quit. You can come back later; progress is saved |

A backup (`.bak`) is written before every save. Nothing becomes verified unless you press `y`.

### What counts as "matches"
- Numbers must match the source (pressure, oxygen, gravity, time). Rounding is fine.
- The claim must not be stronger than the source ("expected to", "may" must stay hedged).
- If the source is a slide deck or a table, note the slide or page in the "page or section" prompt.
- If you cannot open a link (paywall or moved), mark `n` and tell me; I can look for another source.

### The 13 unverified findings
| ID | Claim (shortened) | Open this | Search the source for |
|---|---|---|---|
| F01 | NASA's planned exploration atmosphere for future vehicles and habitats is 56.5 kPa (8.2 psia) with 34% oxygen,... | [Modeling a 15-min EVA prebreathe protocol using NASA's ](https://www.sciencedirect.com/science/article/abs/pii/S0094576514004937) | 34, 8.2, 56.5 |
| F02 | An alternative exploration atmosphere under consideration is 70.3 kPa (10.2 psia) with 26.5% oxygen, and lunar... | [Technology development for spacecraft fire safety (FLAR](https://ntrs.nasa.gov/citations/20210021318) | 10.2, 26.5, 70.3 |
| F03 | NASA has historically used 1g tests to extrapolate flammability and flame propagation in reduced gravity; more... | [Technology development for spacecraft fire safety (FLAR](https://ntrs.nasa.gov/citations/20210021318) | 1 |
| F04 | Theory and experimental results indicate that oxygen flammability limits in lunar gravity are lower than those... | [Technology development for spacecraft fire safety (FLAR](https://ntrs.nasa.gov/citations/20210021318) | 1 |
| F05 | In both 1g and lunar gravity, extinction happens by blow-off. Lower buoyant flow at lunar gravity weakens the... | [Technology development for spacecraft fire safety (FLAR](https://ntrs.nasa.gov/citations/20210021318) | 1 |
| F06 | Normoxic atmospheres (reduced pressure with higher oxygen) help prevent decompression sickness but increase fl... | [Technology development for spacecraft fire safety (FLAR](https://ntrs.nasa.gov/citations/20210021318) | key words |
| F07 | Material flammability limits are not expected to meet current requirements at 34% oxygen and 8.2 psi, and redu... | [Research questions and challenges for improved spacecra](https://science.nasa.gov/wp-content/uploads/2023/05/154_33f28c6ef0c27b92cf1f526cef0c44b4_Fire_detection_white_paper_final_211031.pdf) | 34, 8.2 |
| F08 | An evaluation of heritage hardware found the portable fire extinguisher will not meet flammability requirement... | [Evaluation of heritage hardware for use in cabin enviro](https://ntrs.nasa.gov/citations/20220006612) | 34, 40, 8.2 |
| F09 | Piloted ignition of PMMA was studied in the proposed exploration cabin environment of 52.7 to 58.6 kPa and 30... | [Piloted ignition delay of PMMA in space exploration atm](https://ntrs.nasa.gov/citations/20080013149) | 30, 34, 52.7, 58.6 |
| F10 | The lunar lander and habitat concept combines reduced cabin pressure and higher oxygen (56.5 kPa, 34% or more)... | [NASA materials flammability update (7th FLARE workshop)](https://ntrs.nasa.gov/citations/20210021181) | 10, 20, 34, 0.16, 56.5 |
| F11 | Short-duration simulated lunar-gravity experiments, such as a rotating suborbital capsule giving about 120 s a... | [Research questions and challenges for improved spacecra](https://science.nasa.gov/wp-content/uploads/2023/05/154_33f28c6ef0c27b92cf1f526cef0c44b4_Fire_detection_white_paper_final_211031.pdf) | 34, 120, 8.2, 0.165 |
| F15 | The LUCI investigation produced the first extended-duration (over 25 seconds) combustion tests in simulated lu... | [Lunar combustion investigation: flammability results (L](https://ntrs.nasa.gov/citations/20250010653) | 25 |
| F16 | NASA's decadal survey notes that partial-gravity and microgravity conditions are the most flammable regimes, m... | [Decadal survey on biological and physical sciences rese](https://science.nasa.gov/wp-content/uploads/2023/05/217_5dda37a2b088281953e769f275061ac8_MillerFletcherJ.pdf) | key words |

### The 9 unverified catalog entries
For the catalog, blank fields mean "not recorded"; you do not have to fill them, only confirm that what is filled in is right (or edit it). Entry E05 (LUCI) and E11 (FLARE) have the least recorded: it is fine to leave many fields blank.

| ID | Entry | Values to confirm | Open this |
|---|---|---|---|
| E01 | BASS (Burning and Suppression of Solids) | type ISS, status flown; gravity 0; oxygen % 17 to 22; flow 0 to 42; fuels: PMMA thin flat samples (100 to 400 um) | [source](https://ntrs.nasa.gov/citations/20210011385) |
| E03 | SoFIE (Solid Fuel Ignition and Extinction) | type ISS, status flown; gravity 0; fuels: PMMA cylinders, spheres and slabs (see source) | [source](https://science.nasa.gov/biological-physical/investigations/sofie) |
| E04 | Saffire I to VI | type Free-flyer vehicle, status flown; gravity 0; fuels: Fabric and other materials, samples up to 40.6 by 94 cm | [source](https://ntrs.nasa.gov/citations/20170008805) |
| E05 | LUCI (Lunar Combustion Investigation) | type Suborbital or aircraft, status complete; duration 25; fuels: none recorded | [source](https://ntrs.nasa.gov/citations/20250010653) |
| E06 | ACME (Advanced Combustion via Microgravity Experiments) | type ISS, status complete; gravity 0; fuels: Gaseous fuels; porous burners | [source](https://www1.grc.nasa.gov/wp-content/uploads/ACME_ISRD_revB_20130930_signed.pdf) |
| E08 | NASA-STD-6001 Test 1 (upward flame propagation) | type Ground (1g), status standard; gravity 1; fuels: Spacecraft materials | [source](https://ntrs.nasa.gov/citations/20070018178) |
| E09 | Piloted ignition of PMMA in exploration atmospheres | type Ground (1g), status complete; gravity 1; oxygen % 30 to 34; pressure kPa 52.7 to 58.6; fuels: PMMA | [source](https://ntrs.nasa.gov/citations/20080013149) |
| E10 | Rotating suborbital capsule for lunar-gravity fire tests (planned) | type Planned, status planned; gravity 0.165; oxygen % 34; pressure kPa 56.5; duration 120; fuels: none recorded | [source](https://science.nasa.gov/wp-content/uploads/2023/05/154_33f28c6ef0c27b92cf1f526cef0c44b4_Fire_detection_white_paper_final_211031.pdf) |
| E11 | FLARE (Flammability Limits at Reduced-g Experiment) | type Planned, status planned; none recorded; fuels: Materials (see source) | [source](https://ntrs.nasa.gov/citations/20210021318) |

### After verifying
- Run `python scripts/make_evaluation.py` to refresh `docs/EVALUATION.md` with the new counts.
- Then update the README line "Evidence quality" with your numbers (or tell me and I will).
- Re-run `python -m insights.tests.test_insights` to make sure nothing broke.

---

## Part C. Test the real AI (20 minutes, small cost)

### 1. Get an API key
1. Go to platform.openai.com, sign in, open **API keys**, create a key, and copy it (starts with `sk-`; it is shown once).
2. In **Billing / Limits**, set a **monthly spending limit** (for example 5 dollars). The dashboard also caps itself at 500 AI calls per day, 5 AI briefs per minute per session, and about 400 tokens per answer, so cost stays small; check OpenAI's current price list for `gpt-4o-mini`.

### 2. Give the key to the app (pick one)
- **PowerShell, for this window only:** `$env:OPENAI_API_KEY="sk-your-key"`
- **Command Prompt, for this window only:** `set OPENAI_API_KEY=sk-your-key`
- **Permanent on Windows:** `setx OPENAI_API_KEY "sk-your-key"`, then close and reopen the terminal.
- **Mac or Linux:** `export OPENAI_API_KEY="sk-your-key"`
- **File:** copy `.streamlit/secrets.toml.example` to `.streamlit/secrets.toml` and paste your key. This file is ignored by Git; never commit it or paste a key into chat or code.

### 3. Run and test
1. `streamlit run app/streamlit_app.py`
2. **Mission insights tab**, scenario "Lunar habitat, exploration atmosphere": press **Write with AI (verified)**.
   - Success looks like a green banner "AI-written brief. Citations, numbers and structure were checked", with paragraphs Scenario, Our data, Evidence, Gaps, Follow-up.
   - Opening "What the AI is given" shows the exact facts it received.
   - It is normal for some attempts to fall back: you will see an orange note "Showing the rule-based brief. AI text failed verification: ..." with the reason. That is the safety net working. Try 3 different scenarios; if most fall back for the same reason, send me the reason text and I will adjust the prompt.
   - "service unavailable" means a network, key, or billing problem: check the key, billing, and internet.
3. **AI assistant tab** (needs Part A's index): ask "How does oxygen concentration affect flame spread in microgravity?" You should get an answer with source links. Then ask "best pizza topping": it should decline.
4. Pre-compute the 15 cached answers (so the assistant still works if the AI is down): `python -m rag.build_cache --index rag/index --tau rag/tau.json --out rag/cache.json`. It prints how many were cached and which were skipped.

### 4. Safety
If a key is ever exposed, delete it on the OpenAI site and make a new one.

---

## Part D. Check the flame on your own computer (5 minutes)

1. With the dashboard open, look at the **fps number** in the top right of the flame panel.
2. 30 fps or more: fine. Under 20: close other browser tabs, make sure browser hardware acceleration is on (Chrome: Settings, System), or shrink the window. The flame lowers its own resolution automatically when slow.
3. Tell me your computer or graphics card and the fps if it stays low; I can add a lower-quality mode.
4. Try keyboard use: Tab to the flame, arrow keys move the view, Reset view button restores it.

---

## Part E. Put it online (45 to 90 minutes; accounts required)

You need a free GitHub account and a free Streamlit Community Cloud account (sign in with GitHub at share.streamlit.io).

### 1. Prepare
- The project already contains `requirements.txt` (pinned for the saved model) and `.gitignore` (keeps secrets and the NASA corpus out).
- Decide about the document assistant: it needs `rag/index`, `rag/tau.json`, and heavy packages (`faiss-cpu`, `fastembed`). The index contains **text excerpts of NASA documents**, and NTRS asks that you link to the record rather than redistribute copies. **Simplest and safest: deploy without the index.** The assistant tab then shows "not set up", and everything else (prediction, flame, mission insights, experiments, AI brief) works. Show the assistant from your own computer in the demo.

### 2. Push to GitHub
1. Install Git (git-scm.com) and create an empty repository on github.com (name `flame-in-freefall`; private or public).
2. In the project folder:
```
git init
git add .
git commit -m "Flame in Freefall"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/flame-in-freefall.git
git push -u origin main
```
3. Check on github.com that `.streamlit/secrets.toml` and `rag/corpus` are **not** there.

### 3. Deploy
1. share.streamlit.io, **New app**, pick the repository, branch `main`.
2. **Main file path:** `app/streamlit_app.py`.
3. **Advanced settings:** Python version 3.12; **Secrets:** paste `OPENAI_API_KEY = "sk-your-key"` (or leave empty to keep AI features off).
4. Deploy. The first build takes a few minutes. Open the link.

### 4. Check the live app
- Dashboard loads; flame shows; sliders respond; Mission insights tab works; Experiments tab works.
- "Write with AI" works if you added the key.
- Open the app on a phone or a second computer too.
- If it crashes with out-of-memory or a missing-package error, send me the log (Manage app, Logs).

### 5. Backups for the demo
- Record a 60-second screen video of the flow in DEMO_SCRIPT.md.
- Keep the local copy running too (`streamlit run app/streamlit_app.py`).

---

## Part F. Before you present (30 minutes)

- [ ] Verification done as far as you can; the README "Evidence quality" line matches the real numbers.
- [ ] `python scripts/setup_all.py --offline --skip-install` shows all PASS.
- [ ] Real AI brief tried on three scenarios; you know what a fallback message looks like.
- [ ] Assistant tested (in scope and out of scope).
- [ ] fps checked on the presentation computer; browser zoom at 100 percent; 1080p.
- [ ] Rehearsed `DEMO_SCRIPT.md` once with a timer.
- [ ] Backup video and the live link both open.
- [ ] You can explain: why no Moon prediction, what "unverified" means, how the AI is checked.

---

## What I can still build for you (optional)

Ranking v2 with adjustable weights (C5), extraction of more findings from the NASA documents with your approval of each (C6), report export (C7), natural-language scenarios (C8), summaries (C9). Tell me which, and send `SETUP_REPORT.md` first so I know your documents are in place.
