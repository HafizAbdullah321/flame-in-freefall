# Flame in Freefall: start here

## Windows / Mac / Linux quick start
1. Unzip `flame-in-freefall.zip`. Keep the folder layout (app, backend, phase0, rag, scripts).
2. Open a terminal INSIDE the unzipped folder (the one that contains `scripts` and `app`).
3. Check Python: `python --version` must be 3.10 or newer (3.11 or 3.12 recommended).
4. First run, small NASA harvest:  `python scripts/setup_all.py --per-query 5`
5. Open `SETUP_REPORT.md` and send it to the assistant if anything shows FAIL.
6. Start the dashboard:  `streamlit run app/streamlit_app.py`

## If you see an error when starting the dashboard
1. Update Streamlit: `pip install -U streamlit plotly`
2. Run from the unzipped folder that contains `app` and `backend`: `streamlit run app/streamlit_app.py`
3. Copy the LAST 10 to 15 lines of the terminal and send them to the assistant.

## If a step fails
- "project folders are not all in place": you are not in the unzipped folder.
- "NTRS not reachable": check internet, VPN or proxy; the model and tests still work offline: `python scripts/setup_all.py --offline`.
- faiss-cpu will not install: use Python 3.11 or 3.12 (64-bit).

## Folders
app/ dashboard and 3D flame | backend/ model, guard, tests | phase0/ data audit and the 22 real experiments
rag/ NASA reports search (harvest, index, calibration) | scripts/ one-command setup | docs: ENGINEERING_REQUIREMENTS.md
