# Flame in Freefall

An interactive dashboard on how gravity changes fire. It predicts flame spread rate over thin PMMA in microgravity from real drop-tower experiments, shows the result as a 3D flame, compares it with the experiments, and answers research questions from NASA documents, with sources.

> **Research and educational tool only.** Predictions are statistical estimates from 22 experiments and are not certified fire-safety guidance.

## What it does (answering the challenge: summarize, rank and interpret NASA's fire findings for exploration)
- **Prediction with honesty:** oxygen and fuel coverage in, spread rate and a 90 percent interval out. Anything outside the tested envelope is refused ("Experimental Bounds Exceeded"); sparse regions are flagged.
- **3D flame:** a continuous volumetric flame whose speed follows the predicted rate. 0g is a soft blue sphere, 1g is a rising teardrop (1g is an illustration; the data has no 1g measurements).
- **Charts:** the model curve and its interval against the real experiments, with a text table alternative.
- **Mission insights:** pick a planned environment (ISS cabin, 8.2 psia / 34% O2, 10.2 psia / 26.5% O2, lunar and Mars gravity) or define your own. The dashboard says plainly what our experiments cover and what they do not, shows an evidence map of tested versus planned atmospheres, ranks the most relevant NASA findings (by gravity, atmosphere and topic match, weighted by strength of evidence), gives risk cards by topic (spread, flammability limits, ignition, detection, suppression, materials, ventilation), and writes a sourced brief. An optional AI-written brief is verified in code (citations, numbers, structure) and replaced by the rule-based brief if it fails.
- **Experiments:** browse, filter and compare the experiments and facilities behind the research, with verification badges and source links.
- **AI assistant:** answers only from harvested NASA documents, cites every answer, refuses out-of-scope questions in code before calling the language model, and falls back to cached answers or verbatim passages if the AI is unavailable.

## Look and feel
Deep navy surfaces, raised colored card headers, a purple accent, Roboto and Roboto Slab. The fonts are bundled in `app/static` (served by Streamlit, no internet needed), so keep that folder and the `.streamlit/config.toml` files (repo root and `app/`). Needs Streamlit 1.40 or newer: `pip install -U streamlit`.

## Quick start
```
python --version                     # 3.10 or newer (3.11 or 3.12 recommended)
python scripts/setup_all.py --per-query 5      # installs, audits data, trains, tests, harvests NASA reports, builds the index
streamlit run app/streamlit_app.py
```
Optional AI answers: set `OPENAI_API_KEY` (environment variable or `.streamlit/secrets.toml`), then `make rag-cache`. Without a key the assistant still works with cached answers and passages.
See `README_START_HERE.md` for troubleshooting. If setup reports a problem, send `SETUP_REPORT.md`.

## How it is built
| Part | Folder | Notes |
|---|---|---|
| Data audit | `phase0/` | Canonical schema, unit conversion, quality gate, data card |
| Model and guard | `backend/ffbackend/` | Gaussian Process or linear model, conformal intervals, convex-hull envelope guard |
| Dashboard | `app/` | Streamlit, Plotly, custom 3D component (three.js, bundled) |
| Assistant | `rag/` | NTRS harvest, FAISS index, calibrated refusal threshold, tiered fallback |
| Docs | `docs/`, `ENGINEERING_REQUIREMENTS.md` | Data card, requirements |

## Tests
```
make test            # model, guard, data (synthetic and real)
make test-rag-all    # index, calibration (fixture corpus)
make test-assistant  # assistant with a mock language model
make test-insights   # mission insights: ranking, evidence map, catalog, risk cards, AI brief verifier, app flow (mock LLM)
python tests/test_resources.py                       # memory and latency
python app/tests/test_flame3d.py                     # rendered-pixel tests (needs playwright, pillow, scipy)
python app/tests/test_app_e2e.py                     # real server + browser
python app/tests/test_accessibility.py               # WCAG checks with axe-core (needs `npm install axe-core`)
```
Measured here: prediction p95 about 2 ms; server memory about 250 MB after 30 interactions (before the embedding model is loaded); zero axe violations on the dashboard.

## What only you can do
See `docs/YOUR_CHECKLIST.md`: install and fetch NASA documents, verify the evidence with `python scripts/verify_entries.py findings` and `... catalog`, test the real AI with your key, check the flame's frame rate, and deploy.

## Evidence quality
Findings library: 16 entries, 3 verified against their sources, 13 unverified paraphrases of source excerpts. Experiment catalog: 11 entries, 2 verified. Unverified items are marked in the dashboard. See `docs/EVALUATION.md` (regenerate with `python scripts/make_evaluation.py`) and `docs/DATA_CARD.md`.

## Honest limits
Our own experiments do not cover the exploration atmospheres (oxygen partial pressure about 19 kPa versus the tested 21.5 to 25.3 kPa) or any partial gravity, so for those scenarios the dashboard makes no prediction and shows ranked evidence and data gaps instead.
22 experiments, one apparatus, one fuel (thin PMMA). Oxygen and pressure move together in the data, so there is one oxygen control. No 1g data. The 3D flame is stylized, not a physics simulation. Frame rate depends on your graphics card (the page shows its fps); the renderer lowers its resolution automatically if it is slow.

## Credits and licenses
Experimental data: ZARM drop-tower dataset, Zenodo 18479713 (GPL-3.0-or-later). NASA STI Repository for reports. three.js (MIT). See `phase0/sources/NOTICE.md`.
